#ifndef __FORCE_REAR__
#define __FORCE_REAR__

float damp (float v);
float f_rear(float* x);
void n_rear(float* xl, float* xr, float* n_l, float* n_r);


#endif