#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "force_rear.h"

int main () {
    //printf("Damp %f\n", damp(-6));
    float arr[10] = {1,2,3,4,6,7,8,9,10,11};
    printf("f rear %f\n", f_rear(arr) );
  
    return 0;
}

