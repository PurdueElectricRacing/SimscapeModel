#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/*  
    Ver 1.0, 2/05/22
    
    Function foe determining the force based on a
    simple model in the PDF. Some of the values need to 
    be double checked before applying to the system.

    Ref. 1 F. Janabi-Sharifi, V. Hayward and C. . -S. J. Chen, "Discrete-time adaptive windowing for 
    velocity estimation," in IEEE Transactions on Control Systems Technology, 
    vol. 8, no. 6, pp. 1003-1009, Nov. 2000, doi: 10.1109/87.880606.
*/

#define DELTA   0.001       // sampling rate of the microcontoller, s
#define ERROR   0.001       // error for the windowing algorithm, needs to be tuned.
#define N       10          // number of measurements passed, maximum depth of the algorithm

#define D_D     3.36        // diagonal wheel connection distance
#define D_W     3.36        // damper+spring distance
#define D_A     1.46        // ARB distance
#define GAMMA   2004.75     // torsion coefficient, m*N/rad
#define S       5           // ARB leverage, m
#define COS_A   0.74        // cos_alpha
#define K       146.75      // spring constant, N/m

#define RESOLUTION  0.0001  // convert ADC value to real numbers, resolution of the ADC, 
#define ZERO        0.001   // actual displacement when ADC shows 0


const float FORCE_COMP[] = {    // copy data from one of the csv files, gives the measured compression damping force for a 
          0,                     // particular configuration of valves
    266.907,
    347.769,
    391.315,
    428.215,
    464.746,
    488.642,
    511.53,
    534.269,
    557.547,
    579.819,
    591.2,
    600.593,
    610.17,
    620.067,
    629.761,
    638.914,
    646.8,
    654.686,
    662.572,
    670.458,
    678.211,
    686.843,
    696.301,
    705.759,
    715.218,
};

const float FORCE_REB[] = {    // copy data from one of the csv files, gives the measured rebound damping force for a 
           0,                     // particular configuration of valves
    -232.487,
    -290.239,
    -324.172,
    -349.805,
    -374.158,
    -394.209,
    -413.159,
    -433.588,
    -453.067,
    -469.533,
    -485.999,
    -497.792,
    -509.725,
    -521.864,
    -534.617,
    -543.42,
    -550.862,
    -558.305,
    -566.015,
    -574.208,
    -582.04,
    -589.937,
    -598.443,
    -606.955,
    -615.468,
};

/*
    Calculates damping force based on the data from dyno tests. The data was digitized and put into corresponding
    *.csv files where the force is interpolted for values 0, 10, 20, ..., 250. This basically implements further 
    first oreder interpolation.
*/

float damp (float v) {
    int val= (int)(floor(fabs(v/10)));
    if (v > 0) {
        return (FORCE_COMP[val] * (val * 10 + 10 - v) + FORCE_COMP[val + 1] * (v - val * 10)) / 10;
    } else {
        return (FORCE_REB[val] * (v + val * 10 + 10) + FORCE_REB[val + 1] * (- val * 10 - v)) / 10;
    }
}

/*
    This is the main calculation function. It adjusts sampling window according to, 
    basically, change in speed. If the speed changes quickly, the estimator use only
    first few measurements to reduce the delay. If the speed chages slowly, 
    it adds more points t0 increase precision. The parameter ERROR that regulates this should be tuned 
    to achieve the best performance

    Input: sequence of the last N measurements of ADC.
    Return: suspension unit force

    front wheel: coming up...
*/

float f_rear(int* x) {     // implements adaptive windowing as described in (1)

    float b = 0;
    float b_old = 0;

    for (int i = 1; i < N; i++) {               // initialize thr loop over the window size
        float s1 = 0;                           // variables for summation
        float s2 = 0;
        for (int j = 0; j<=i; j++) {
            s1 += x[j];
            s2 += j * x[j];
        }
        b = (i * s1 - 2 * s2) / (i + 1) / (i + 2) / i * 6;                  // implementing the formula from the paper.
        for (int j = 1; j<=i; j++) {
            if (fabs(x[j] - (x[0] - j * b)) > ERROR) {
                return -K * (x[0] * RESOLUTION + ZERO) + damp(RESOLUTION * b_old / DELTA);        // returing the spring force + damping force
            }
        }
        b_old = b;
    }
    return -K * (x[0] * RESOLUTION + ZERO) - damp(RESOLUTION * b_old / DELTA);
}

void n_rear(float* xl, float* xr, float* n_l, float* n_r) {
    *n_l=(f_rear(xl) * D_D + ( GAMMA * (D_A / D_D) * (xr[0] - xl[0])) / (S * S) * D_A) / (D_W * COS_A);
    *n_r=(f_rear(xr) * D_D + ( GAMMA * (D_A / D_D) * (xl[0] - xr[0])) / (S * S) * D_A) / (D_W * COS_A);
}